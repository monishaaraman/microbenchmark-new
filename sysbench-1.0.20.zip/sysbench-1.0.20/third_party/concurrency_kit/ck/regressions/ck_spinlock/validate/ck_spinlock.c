#include "../ck_spinlock.h"
#include "validate.h"
